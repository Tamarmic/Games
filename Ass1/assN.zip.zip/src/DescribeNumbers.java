// 323805861 Tamar Michelson

/**
 *
 */
public class DescribeNumbers {
    /**
     * @param args 0
     */
    public static void main(String[] args) {
        //  int min=Integer.parseInt(args[0]);

        int[] intArray = stringsToInts(args);
        System.out.println("min:" + min(intArray));
        System.out.println("max" + max(intArray));
        System.out.println("avg" + avg(intArray));
    }

    /**
     * .
     * Function that passes an array of strings to an array of int
     *
     * @param numbers i
     * @return p
     */
    public static int[] stringsToInts(String[] numbers) {
        int[] intArray;    //declaring array
        int length = numbers.length;
        intArray = new int[length];
        for (int i = 0; i < length; i++) {
            intArray[i] = Integer.parseInt(numbers[i]);
        }
        return intArray;
    }

    /**
     * .
     * A function that goes through the array and calculates its minimum
     *
     * @param numbers i
     * @return a
     */
    public static int min(int[] numbers) {
        int length = numbers.length;
        int min = numbers[0];
        for (int i = 1; i < length; i++) {
            if (numbers[i] < min) {
                min = numbers[i];
            }
        }
        return min;
    }

    /**
     * .
     * A function that goes through the array and calculates its maximum
     *
     * @param numbers i
     * @return a
     */
    public static int max(int[] numbers) {
        int length = numbers.length;
        int max = numbers[0];
        for (int i = 1; i < length; i++) {
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        return max;
    }

    /**
     * .
     *
     * @param numbers i
     * @return a
     *                A function that calculates the averege of the array
     */
    public static float avg(int[] numbers) {
        int length = numbers.length;
        float avg = numbers[0];
        for (int i = 1; i < length; i++) {
            avg = avg + numbers[i];
        }
        avg = avg / length;
        return avg;
    }
}
