//
/**
 * .
 */
public class PrintingHitListener implements HitListener {
    /**
     * .
      * @param beingHit
     * @param hitter
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        System.out.println("A Block was hit.");
    }
}